package code;
import java.io.*;
import java.sql.*;
import java.util.*;



public class MethodsToImplement {

	public  List<Movie> populateMovies(File file){
		List<Movie> movieArr=new ArrayList<Movie>();
	    try {
	    	Scanner sc = new Scanner(file);
			while (sc.hasNextLine())
			{
				Movie m=new Movie();
			    String[] parts = sc.nextLine().split(",");
					    if (parts.length >= 8)
					    {
					        m.setMovieId(Integer.parseInt(parts[0]));
					        m.setMovieName(parts[1]);
					        m.setTotalBusinessDone(Double.parseDouble(parts[2]));
					        m.setRating(Double.parseDouble(parts[3]));
							m.setReleaseDate(java.sql.Date.valueOf(parts[4]));
					        m.setLanguage(parts[5]);
					        m.setMovieType(parts[6]);
					        List<String> temp = new ArrayList<String>();
					        for(int i = 7; i < parts.length; i++) {
					        	temp.add(parts[i]);
					        }
					        m.setCasting(temp);
					        
					    } 
					    movieArr.add(m);
					}
					
					sc.close();
	    } 
	    catch (Exception e) {System.out.println(e);}
	    return movieArr;
	}
	
	public Boolean allMoviesInDb(List<Movie> movies)
	{
		if(movies != null)
		{
			Connection cn=MySqlCon.getConnection();
			for(Movie m:movies)
			{
				PreparedStatement pstmt = null;
				try {
					pstmt = cn.prepareStatement("insert into moviestb values(?,?,?,?,?,?,?,?)");
					pstmt.setInt(1,m.getMovieId());
					pstmt.setString(2, m.getMovieName() );
					pstmt.setDouble(3, m.getTotalBusinessDone());
					pstmt.setDouble(4, m.getRating() );
					pstmt.setDate(5,m.getReleaseDate());
					pstmt.setString(6, m.getLanguage().getLang());
					pstmt.setString(7, m.getMovieType().getCategory());
					String temp = m.getCasting().toString();
					pstmt.setString(8,temp.substring(1, temp.length()-1));
					pstmt.executeUpdate();
				
				}
				catch (SQLException e) { System.out.println(e);}
			}
			try { cn.close();}
	        catch (SQLException e) {System.out.println(e);}
			return true;
		}
		return false;
	}
		
	public void addMovie(Movie movie,List<Movie> movies) {
		boolean flag = false;
		if(movies != null) {
			for(Movie m:movies) {
				if(m.getMovieId() == movie.getMovieId()) {flag = true;}
			}
		}
		else {movies.add(movie);}
		if(flag == false) {movies.add(movie);}
	}
	
	public void serializeMovies(List<Movie> movies, String fileName) {
		try {
			FileOutputStream fileOut = new FileOutputStream(fileName);
			ObjectOutputStream out = new ObjectOutputStream(fileOut);
			out.writeObject(movies);
			out.close();
			fileOut.close();
			System.out.println("\nSerialization Successful...\n");
 
		} 
		catch (Exception e) {System.out.println(e);}
	}
	public List<Movie> deserializeMovie(String fileName){
		ArrayList<Movie> movies=new ArrayList<Movie>();
		try {
			FileInputStream fileIn = new FileInputStream(fileName);
			ObjectInputStream in = new ObjectInputStream(fileIn);
			try {
				movies=(ArrayList<Movie>)in.readObject();
			} 
			catch (ClassNotFoundException e) {System.out.println(e);}
			in.close();
			fileIn.close();
		} 
		catch (Exception e) {System.out.println(e);}
		return movies;
	}
	
	public List<Movie> getMoviesRealeasedInYear(int year){
		Connection cn=MySqlCon.getConnection();
		List<Movie> movies=new ArrayList<Movie>();
		String query="select * from moviestb where releaseDate like '"+String.valueOf(year)+"______';";
		try {
			Statement stmt = cn.createStatement();
			 ResultSet rs = stmt.executeQuery(query);
			 while(rs.next())
			 {
				 Movie m1=new Movie();
				 m1.setMovieId(rs.getInt(1));
				 m1.setMovieName(rs.getString(2));
				 m1.setTotalBusinessDone(rs.getDouble(3));
				 m1.setRating(rs.getDouble(4));
				 m1.setReleaseDate(rs.getDate(5));
				 m1.setLanguage(rs.getString(6));
				 m1.setMovieType(rs.getString(7));
				 String[] temp = rs.getString(8).split(",");
				 List<String> crew = new ArrayList<String>();
				 if(temp != null) {
					 for(String i : temp) {crew.add(i);}
				 }
				 m1.setCasting(crew);
				 movies.add(m1);
			 }
		} 
		catch (Exception e) {System.out.println(e);}
		try { cn.close();}
	    catch (SQLException e) {System.out.println(e);}
		return movies;
	}
	
	public List<Movie> getMoviesByActor(String... actorNames){
		
		Connection cn=MySqlCon.getConnection();
		List<Movie> movies=new ArrayList<Movie>();
		String condition = "movieCast LIKE '%"+actorNames[0]+"%'";
		if(actorNames.length > 1) {
			for(int i = 1; i < actorNames.length; i++) {
				condition += "AND movieCast LIKE '%"+actorNames[i]+"%'";
			}
		}
		String query="select * from moviestb where "+condition;
		System.out.println(query);
		try {
			Statement stmt = cn.createStatement();
			 ResultSet rs = stmt.executeQuery(query);
			 while(rs.next())
			 {
				 Movie m1=new Movie();
				 m1.setMovieId(rs.getInt(1));
				 m1.setMovieName(rs.getString(2));
				 m1.setTotalBusinessDone(rs.getDouble(3));
				 m1.setRating(rs.getDouble(4));
				 m1.setReleaseDate(rs.getDate(5));
				 m1.setLanguage(rs.getString(6));
				 m1.setMovieType(rs.getString(7));
				 String[] temp = rs.getString(8).split(",");
				 List<String> crew = new ArrayList<String>();
				 if(temp != null) {
					 for(String i : temp) {crew.add(i);}
				 }
				 m1.setCasting(crew);
				 movies.add(m1);
			 }
		} 
		catch (Exception e) {System.out.println(e);}	
		try { cn.close();}
	    catch (SQLException e) {System.out.println(e);}
		return movies;
	}

	public void updateRatings(Movie movie, double rating ,List<Movie> movies) {
		if(movies != null) {
			for(Movie m: movies) {
				if(movie.equals(m)) {
					m.setRating(rating);
					break;
				}
			}
		}
	}
	
	public void updateBusiness(Movie movie, double amount,List<Movie> movies) {
		if(movies != null) {
			for(Movie m: movies) {
				if(movie.equals(m)) {
					m.setTotalBusinessDone(amount);
					break;
				}
			}
		}
	}
	
	public Map<Language,Set<Movie>> businessDone(double amount){
		Connection cn=MySqlCon.getConnection();
		Map<Language,Set<Movie>> movieMap = new HashMap<Language,Set<Movie>>();
		TreeSet<String> languages=new TreeSet<String>();
		List<Movie> movies=new ArrayList<Movie>();
		String query="select * from moviestb where TotalBusinessDone >= "+amount;
		try {
			Statement stmt = cn.createStatement();
			 ResultSet rs = stmt.executeQuery(query);
			 while(rs.next())
			 {
				 Movie m1=new Movie();
				 m1.setMovieId(rs.getInt(1));
				 m1.setMovieName(rs.getString(2));
				 m1.setTotalBusinessDone(rs.getDouble(3));
				 m1.setRating(rs.getDouble(4));
				 m1.setReleaseDate(rs.getDate(5));
				 m1.setLanguage(rs.getString(6));
				 m1.setMovieType(rs.getString(7));
				 String[] temp = rs.getString(8).split(",");
				 List<String> crew = new ArrayList<String>();
				 if(temp != null) {
					 for(String i : temp) {crew.add(i);}
				 }
				 m1.setCasting(crew);
				 languages.add(m1.getLanguage().getLang());
				 movies.add(m1);
			 }
		} 
		catch (SQLException e) {System.out.println(e);}
		try { cn.close();}
	    catch (SQLException e) {System.out.println(e);}
	
		Iterator<String> langItr = languages.iterator();  
		while(langItr.hasNext()){ 
			String lang = langItr.next();
			TreeSet<Movie> movieSet = new TreeSet<Movie>();
			
			Iterator<Movie> movieItr = movies.iterator();
			while(movieItr.hasNext()){  
				Movie m = movieItr.next();
				if(m.getLanguage().getLang().equals(lang)) {
					movieSet.add(m);
				}
			}  

			movieMap.put(new Language(lang), (TreeSet<Movie>)movieSet.descendingSet());
		}
		
		return movieMap;
	}
	
	public int searchMovieByID(int mid, List<Movie> movies) {
		if(movies != null) {
			for(Movie m: movies) {
				if(m.getMovieId() == mid) {
					return movies.indexOf(m);
				}
			}
		}
		return -1;
	}
	
	public void displayMovies(List<Movie> movies) {
		System.out.printf("%10s%10s%20s%10s%15s%10s%10s\n\n","ID","TITLE","TOTAL BUSINESS","RATING","RELEASE DATE","LANGUAGE","TYPE");
		System.out.println("-------------------------------------------------------------------------------------------------------------------------");
		if(movies != null) {

			for(Movie m : movies) {
				System.out.printf("%10s%10s%20s%10s%15s%10s%10s",m.getMovieId(),m.getMovieName(),m.getTotalBusinessDone(),m.getRating(),m.getReleaseDate(),m.getLanguage().getLang(),m.getMovieType().getCategory());
				List<String>temp = m.getCasting();
				System.out.print("\nCast : ");
				if(temp != null) {
					for(String k : temp) { System.out.print(k+",");	}
				}
				System.out.println("\n-------------------------------------------------------------------------------------------------------------------------");
			}
		}
		
		
	}
	
}
