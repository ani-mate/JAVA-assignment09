package code;
import java.io.Serializable;
public class Category implements Serializable{
	String genre;
	Category(String genre){this.genre = genre;}
	public String getCategory() {return genre;}
	public void setCategory(String genre) {this.genre = genre;}
}
