package code;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
public class MySqlCon {
	static String url="jdbc:mysql://localhost:3306/assignment9";
	static String driverClass="com.mysql.cj.jdbc.Driver";
	static String username="root";
	static String password="root";

	public static Connection getConnection() {
		Connection cn = null;
		try {
				Class.forName(driverClass);
				try {
					cn = DriverManager.getConnection(url,username,password);
				}
				catch (SQLException e) { System.out.println(e); }
		}
		catch (ClassNotFoundException e) {System.out.println(e);}
		return cn;
	}

}
