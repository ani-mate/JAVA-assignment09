package code;

import java.util.*;
import java.io.*;

public class Main {

	public static void main(String[] args) {
		MethodsToImplement mti = new MethodsToImplement();
		List<Movie> movies = new ArrayList<Movie>();
		int choice;
		char again ;
		String filepath;
		int id,pos;
		double newRating, tbd;
		Scanner sc = new Scanner(System.in);
		do {
			System.out.println("1. READ DATA FROM FILE");
			System.out.println("2. STORE ALL MOVIES INTO DB");
			System.out.println("3. ADD NEW MOVIE TO LIST");
			System.out.println("4. SERIALIZE MOVIE DATA");
			System.out.println("5. DESERIALIZE MOVIE DATA FROM FILE");
			System.out.println("6. FIND MOVIES RELEASED IN GIVEN YEAR");
			System.out.println("7. FIND MOVIES BY ACTORS");
			System.out.println("8. UPDATE MOVIE RATING");
			System.out.println("9. UPDATE BUSINESS DONE BY MOVIE");
			System.out.println("10. LANGUAGE-MOVIES SORTED BY TOTAL BUSINESS DONE (DESCENDING)");
			System.out.println("11. DISPLAY CURRENT MOVIE LIST");
			System.out.print("--->");
			choice = Integer.parseInt(sc.nextLine());
			switch(choice) {
				case 1:
					filepath = "C:\\Users\\aniket\\Desktop\\assignment\\assignment09\\src\\textfiles\\movies.txt";
					File file = new File(filepath);
					movies = mti.populateMovies(file);
					break;
				
				case 2:
					mti.allMoviesInDb(movies);
					break;
				case 3:
					Movie movie = new Movie();
					System.out.println("Enter ID, Title, Total Business Done, Rating, Release Date, Language, Type and Cast separated by comma in order");
					String[] parts = sc.nextLine().split(",");
					movie.setMovieId(Integer.parseInt(parts[0]));
			        movie.setMovieName(parts[1]);
			        movie.setTotalBusinessDone(Double.parseDouble(parts[2]));
			        movie.setRating(Double.parseDouble(parts[3]));
					movie.setReleaseDate(java.sql.Date.valueOf(parts[4]));
			        movie.setLanguage(parts[5]);
			        movie.setMovieType(parts[6]);
			        List<String> temp = new ArrayList<String>();
			        for(int i = 7; i < parts.length; i++) {
			        	temp.add(parts[i]);
			        }
			        movie.setCasting(temp);
			        mti.addMovie(movie, movies);
					break;
				case 4:
					filepath = "C:\\Users\\aniket\\Desktop\\assignment\\assignment09\\src\\textfiles\\serializedMovies.txt";
					mti.serializeMovies(movies, filepath);
					break;
				case 5:
					filepath = "C:\\Users\\aniket\\Desktop\\assignment\\assignment09\\src\\textfiles\\serializedMovies.txt";
					mti.displayMovies(mti.deserializeMovie(filepath));
					break;
				case 6:
					System.out.print("Enter Year : ");
					int year = sc.nextInt();
					sc.nextLine();
					mti.displayMovies(mti.getMoviesRealeasedInYear(year));
					break;
				case 7:
					System.out.print("Enter cast (e.g. mark,leo) : ");
					String[] crew = sc.nextLine().split(",");
					mti.displayMovies(mti.getMoviesByActor(crew));
					break;
				case 8:
					mti.displayMovies(movies);
					System.out.println("Enter movie ID : ");
					id = sc.nextInt();
					System.out.println("Enter new rating : ");
					newRating = sc.nextDouble();
					sc.nextLine();
					pos = mti.searchMovieByID(id, movies);
					if(pos>=0) {
						mti.updateRatings(movies.get(pos), newRating, movies);
					}
					else {
						System.out.println("No movie found with given ID");
					}
					break;
				case 9:
					mti.displayMovies(movies);
					System.out.println("Enter movie ID : ");
					id = sc.nextInt();
					System.out.println("Enter Total Business Done : ");
					tbd = sc.nextDouble();
					sc.nextLine();
					pos = mti.searchMovieByID(id, movies);
					if(pos>=0) {
						mti.updateBusiness(movies.get(pos), tbd, movies);
					}
					else {
						System.out.println("No movie found with given ID");
					}
					break;
				case 10:
					System.out.print("Enter Total Business Done : ");
					tbd = sc.nextDouble();
					sc.nextLine();
					Map<Language,Set<Movie>> movieMap = mti.businessDone(tbd);
					System.out.printf("%20s%10s%20s%10s\n","Language","ID","Title","Business");
					for(Map.Entry<Language, Set<Movie>> mm : movieMap.entrySet()) {
						for(Movie m : mm.getValue()) {
							System.out.printf("%20s%10s%20s%10s\n",mm.getKey().getLang(), m.getMovieId(),m.getMovieName(),m.getTotalBusinessDone());
						}
						System.out.println();
						System.out.println("\n-------------------------------------------------------------------------------------------------------------------------");
					}
					break;
				case 11:
					mti.displayMovies(movies);
					break;
				default:
					System.out.println("Invalid Choice ! ");
					break;
			}
			System.out.print("Do you wish to continue (y/n) : ");
			again = sc.next().charAt(0);
			sc.nextLine();
		}while(again == 'y');
		sc.close();
		System.out.print("END !");

	}

}
