package code;
import java.io.Serializable;
public class Language implements Serializable {
	String lang;
	Language(String lang){this.lang = lang;}
	public String getLang() {return lang;}
	public void setLang(String lang) {this.lang = lang;}
	
}
