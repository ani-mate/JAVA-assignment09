package code;

import java.io.Serializable;
import java.sql.Date;
import java.util.*;


public class Movie implements Serializable,Comparable<Movie>{
	private int movieId;
	private String movieName;
	private double totalBusinessDone;
	private double rating;
	private Date releaseDate;
	private Language language;
	private Category movieType;
	private List<String> casting = new ArrayList<String>();
	
	
	public int getMovieId() {return movieId;}
	public void setMovieId(int movieId) {this.movieId = movieId;}
	public String getMovieName() {return movieName;}
	public void setMovieName(String movieName) {this.movieName = movieName;}
	public double getTotalBusinessDone() {return totalBusinessDone;}
	public void setTotalBusinessDone(double totalBusinessDone) {this.totalBusinessDone = totalBusinessDone;}
	public double getRating() {return rating;}
	public void setRating(double rating) {this.rating = rating;}
	public Date getReleaseDate() {return releaseDate;}
	public void setReleaseDate(Date releaseDate) {this.releaseDate = releaseDate;}
	
	public String toString() {
		return "Movies [movieId=" + movieId + ", movieName=" + movieName + ", totalBusinessDone=" + totalBusinessDone
				+ ", rating=" + rating + ", releaseDate=" + releaseDate + ", language=" + language + ", movieType="
				+ movieType + ", casting=" + casting + "]";
	}
	public Language getLanguage() {return language;}
	public void setLanguage(String language) {this.language = new Language(language);}
	public Category getMovieType() {return movieType;}
	public void setMovieType(String movieType) {this.movieType = new Category(movieType);}
	public List<String> getCasting() {return casting;}
	public void setCasting(List<String> crew) {
		if(crew != null) {
			for(String i:crew) {
				this.casting.add(i);
			}
		}
	}
	
	public int compareTo(Movie m) {
		return (int) this.getTotalBusinessDone() - (int) m.getTotalBusinessDone();
	}
	
}
